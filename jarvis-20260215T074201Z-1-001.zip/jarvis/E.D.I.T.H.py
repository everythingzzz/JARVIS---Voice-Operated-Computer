import pyttsx3 #pip install pyttsx3
import speech_recognition as sr #pip install speechRecognition
import datetime
import wikipedia #pip install wikipedia
import webbrowser
import os
import smtplib
import pywhatkit as kit
from time import ctime
import time

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour>=0 and hour<12:
        speak("Good morning Sir!")
    elif hour>=12 and hour<4:
        speak("Good afternoon Sir!")
    else:
        speak("Good Evening Sir!")

    speak("I am EDITH!")
    
def takeCommand():
    # takes my command from microphone and gives text
    r =sr.Recognizer()
    with sr.Microphone() as source:
       print("Listening...")
       r.energy_threshold = 1200
       audio = r.listen(source)
                    
    try:
       print("Recognizing...")
       query = r.recognize_google(audio, language ='en-in')
       print("user said : ", query)
    except Exception as e:
       print(e)
       print("Sorry Sir!, can you repeat that again?")
       speak("Sorry Sir!, can you repeat that again?")
       return "None"

    return query

if __name__ == "__main__":
    wishMe()
    while True:
        speak("How can i help you?")
        query = takeCommand().lower()
    
        # Logic for executing tasks as per the query    
        if 'wikipedia' in query.lower():
            speak('Searching wikipedia...')
            query = query.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences =2)
            print(results)
            speak(results)


        # Open url in a new window of the default browser
        elif 'open youtube' in query.lower():
            url = 'youtube.com'
            chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'
            webbrowser.get(chrome_path).open(url)
            

        elif 'open google' in query.lower():
            url = 'google.com'
            chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'
            webbrowser.get(chrome_path).open(url)
            

        elif 'time' in query.lower():
           print(ctime())
           speak(ctime())
        

        elif 'search on google' in query.lower():
            query = query.replace("search on google", "")
            chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'
            webbrowser.get(chrome_path).open('https://google.com/?#q=' + query)
            


        elif 'search on youtube' in query.lower():
            query = query.replace("search on youtube", "")
            chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'
            webbrowser.get(chrome_path).open('https://www.youtube.com/results?search_query=' + query)
            


        elif 'hello' in query.lower():
            print("Hello Sir!")
            speak("Hello Sir!")
            
        elif 'thank you' in query.lower():
            print("Welcome Sir! see you soon")
            speak("Welcome Sir! see you soon")
            exit()

        elif 'how are you' in query.lower():
            print("I am Good Sir!")
            speak("I am Good Sir!")


        elif 'hell' in query.lower():
            print("I am Sorry Sir!")
            speak("I am Sorry Sir!")
           

        elif 'go away' in query.lower():
            print("I am Sorry Sir!")
            speak("I am Sorry Sir!")
            exit()


        elif 'bye' in query:
            print("see you soon Sir!")
            speak("see you soon Sir!")
            exit()
        
      