cd E:\jarvis
python jarvis.py
exit